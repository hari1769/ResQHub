const functions = require('firebase-functions/v2');
const admin = require('firebase-admin');
const nodemailer = require('nodemailer');
const twilio = require('twilio');

admin.initializeApp();
const db = admin.firestore();

// -----------------------------------------------------
// CONFIGURATION: Set these via Firebase Functions Config
// or environment variables in a real production app.
// -----------------------------------------------------

// Email Settings
const APP_EMAIL = process.env.APP_EMAIL || 'no-reply@safelink-app.com';
const FOUNDER_EMAIL = 'hariharanpalani176@gmail.com';
const SMTP_USER = process.env.SMTP_USER || 'your-smtp-user';
const SMTP_PASS = process.env.SMTP_PASS || 'your-smtp-pass';

const mailTransport = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: SMTP_USER,
        pass: SMTP_PASS,
    },
});

// Twilio Settings
const TWILIO_SID = process.env.TWILIO_SID || 'ACxxxxxxxxxxxxxxxxx';
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN || 'your_auth_token';
const TWILIO_PHONE_NUMBER = process.env.TWILIO_PHONE_NUMBER || '+1234567890';
const twilioClient = new twilio(TWILIO_SID, TWILIO_AUTH_TOKEN);


// -----------------------------------------------------
// FEATURE 1: Founder Login Notification (Email)
// -----------------------------------------------------
exports.onUserLogin = functions.firestore.onDocumentCreated('user_logins/{loginId}', async (event) => {
    const loginData = event.data.data();
    
    if (!loginData) return;

    const mailOptions = {
        from: `SafeLink Monitor <${APP_EMAIL}>`,
        to: FOUNDER_EMAIL,
        subject: `New SafeLink Login Alert: ${loginData.name}`,
        html: `
            <div style="font-family: Arial, sans-serif; padding: 20px; color: #333;">
                <h2 style="color: #2563eb;">SafeLink Login Notification</h2>
                <p>A user has just logged into the SafeLink application.</p>
                <table style="border-collapse: collapse; width: 100%; max-width: 500px;">
                    <tr style="background: #f3f4f6;"><td style="padding: 10px; border: 1px solid #ddd;"><strong>Name</strong></td><td style="padding: 10px; border: 1px solid #ddd;">${loginData.name}</td></tr>
                    <tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Email</strong></td><td style="padding: 10px; border: 1px solid #ddd;">${loginData.email}</td></tr>
                    <tr style="background: #f3f4f6;"><td style="padding: 10px; border: 1px solid #ddd;"><strong>Location</strong></td><td style="padding: 10px; border: 1px solid #ddd;">${loginData.location || 'Unknown'}</td></tr>
                    <tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Device</strong></td><td style="padding: 10px; border: 1px solid #ddd;">${loginData.device || 'Unknown'}</td></tr>
                    <tr style="background: #f3f4f6;"><td style="padding: 10px; border: 1px solid #ddd;"><strong>IP Address</strong></td><td style="padding: 10px; border: 1px solid #ddd;">${loginData.ip || 'Unknown'}</td></tr>
                    <tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Time</strong></td><td style="padding: 10px; border: 1px solid #ddd;">${new Date(loginData.loginTime).toLocaleString()}</td></tr>
                </table>
            </div>
        `
    };

    try {
        await mailTransport.sendMail(mailOptions);
        console.log(`[Email Sent] Founder notified of login by ${loginData.email}`);
    } catch (error) {
        console.error('Error sending login email:', error);
    }
});


// -----------------------------------------------------
// FEATURE 2: Emergency SOS SMS Alert to Contacts
// -----------------------------------------------------
exports.dispatchSOSAlerts = functions.https.onCall(async (request) => {
    // Determine the caller's ID (Requires auth)
    const uid = request.auth ? request.auth.uid : 'u1'; // 'u1' for testing if unauthenticated
    const locationStr = request.data.location || 'Unknown Location';
    const userName = request.data.userName || 'A SafeLink User';
    
    try {
        // Fetch emergency contacts for the user
        const snapshot = await db.collection('emergency_contacts').where('userId', '==', uid).get();
        if (snapshot.empty) {
            console.log(`No emergency contacts found for user ${uid}`);
            return { status: 'success', messagesSent: 0 };
        }

        const mapLink = `https://maps.google.com/?q=${locationStr.replace(' ', '')}`;
        const messageBody = `EMERGENCY ALERT from SafeLink.\n\n${userName} may be in danger.\nLocation: ${mapLink}`;
        
        const smsPromises = [];
        let numSent = 0;

        snapshot.forEach((doc) => {
            const contact = doc.data();
            if (contact.phoneNumber) {
                // Dispatch SMS via Twilio
                const promise = twilioClient.messages.create({
                    body: messageBody,
                    from: TWILIO_PHONE_NUMBER,
                    to: contact.phoneNumber
                }).then(() => {
                    numSent++;
                    console.log(`SOS SMS sent to ${contact.phoneNumber}`);
                }).catch((err) => {
                    console.error(`Failed to send SMS to ${contact.phoneNumber}:`, err);
                });
                smsPromises.push(promise);
            }
        });

        // Wait for all SMS dispatches
        await Promise.allSettled(smsPromises);
        
        return { status: 'success', messagesSent: numSent };

    } catch (error) {
        console.error('Error dispatching SOS Alerts:', error);
        throw new functions.https.HttpsError('internal', 'Failed to dispatch SOS alerts via Twilio.');
    }
});
