# SafeLink - Disaster Management Application

SafeLink is a modern, responsive, emergency and disaster management platform designed to help communities respond to crises quickly and efficiently. Built with React, Tailwind CSS, and Leaflet, it provides an all-in-one suite for SOS tracking, emergency broadcasts, and location intelligence.

## 🌟 Features

- **Auth & Dashboards**: Dedicated views for regular users, incident coordinators, and administrators.
- **Active SOS Map (Live-Tracking)**: Real-time map displaying critical incidents, shelters, hospitals, and safe zones.
- **Emergency Broadcasts**: System allowing administrators to push global weather warnings and disaster alerts to all users.
- **AI Assistant**: Built-in conversational AI to provide immediate disaster safety advice and first response guidelines.
- **Offline Mode**: Fully capable web app with offline caching and automatic synchronization of disaster reports once connectivity is restored.
- **Push Notifications**: Receive nearby SOS signals and critical broadcasts.

---

## 🚀 Quick Setup & Deployment

SafeLink is currently combined into a **single, portable HTML file** (`index.html`) using React via CDN, making it incredibly easy to deploy instantly on GitHub Pages without any build steps.

### Running Locally
1. Clone the repository: `git clone https://github.com/yourusername/safelink.git`
2. Open `index.html` directly in your browser.
3. No build tools (like Webpack or Vite) are required for this setup.

### Deploying to GitHub Pages
Because the entire application runs natively in the browser without a build step:
1. Push your repository to GitHub.
2. Go to your repository settings on GitHub.
3. Navigate to **Pages** on the left-hand sidebar.
4. Under **Source**, select `main` (or `master`) branch and click **Save**.
5. Within a few minutes, your application will be live at `https://yourusername.github.io/safelink/`.

---

## 🔧 Upgrading to Real Firebase (Production)

The current application uses heavily robust **mock implementations** to simulate Authentication, Firestore Realtime Database, Cloud Storage, and Cloud Messaging, so you can preview the UI perfectly out of the box.

To transition to a real Firebase production environment:
1. Open `index.html`.
2. Locate the Firebase mock initialization at the top of the `<script type="module">` tag.
3. Uncomment the actual Firebase initialization lines:
   ```javascript
   const app = initializeApp(firebaseConfig);
   const auth = getAuth(app);
   const db = getFirestore(app);
   ```
4. Replace `firebaseConfig` with your actual project keys from the Firebase Console.
5. Replace the calls to `window.firebaseMock` throughout the React components with standard Firebase SDK calls (`signInWithEmailAndPassword`, `addDoc`, `onSnapshot`, etc.).

### Deploying Backend Services (Emails & SMS)
SafeLink includes a Serverless Backend via Firebase Cloud Functions in the `functions` directory. It uses `nodemailer` to alert Founders of new sign-ins, and `twilio` to securely text Emergency Contacts instantly when an SOS is deployed.
1. `cd functions`
2. Run `npm install`
3. Set your environment keys (e.g `firebase functions:config:set twilio.sid="ACxxx" twilio.token="yyy"`)
4. Run `firebase deploy --only functions`

---

## 🎨 Technology Stack
- **Frontend Framework**: React 18 (via unpkg/Babel)
- **Backend Architecture**: Firebase Cloud Functions (Node.js 20)
- **Styling**: Tailwind CSS (via CDN)
- **Maps**: Leaflet.js
- **Icons**: Custom embedded SVG iconography
- **Fonts**: Inter (Google Fonts)
- **AI Integration**: OpenAI GPT-3.5-turbo (Browser Fetch)

Made for hackathons, emergency response portfolios, and startup concepts.
